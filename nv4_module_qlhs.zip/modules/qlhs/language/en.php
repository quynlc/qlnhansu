<?php

/**
 * @Project NUKEVIET 4.x
 * @Author Vàng Văn Quyn (quynlc@gmail.com)
 * @Copyright (C) 2016 Vàng Văn Quyn. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Thu, 25 Feb 2016 14:05:13 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = 'Vàng Văn Quyn (quynlc@gmail.com)';
$lang_translator['createdate'] = '25/02/2016, 14:05';
$lang_translator['copyright'] = '@Copyright (C) 2016 VINADES.,JSC. All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['lophoc'] = "Classname";
$lang_module['hocsinh'] = "Student";
$lang_module['search'] = "Search";
$lang_module['main'] = "Main";
